<script src="assets/js/jquery-3.6.0.min.js"></script>
<script src="assets/js/bootstrap/bootstrap.bundle.min.js"></script>
<script src="assets/js/script.js"></script>
<script src="../toast/jquery.toast.js"></script>
<script src="../toast/toast-functions.js"></script>