<?php header("location:con-cot/logout.php");?>
